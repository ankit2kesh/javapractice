package hackerrank_test4;

import java.util.Arrays;
import java.util.List;

public class GroupingDigits {

	static int minMoves(int arr[], int n) {
		int noOfZeroes[] = new int[n];
		int i, count = 0;

		// Count number of zeroes
		// on right side of every one.
		noOfZeroes[n - 1] = 1 - arr[n - 1];
		for (i = n - 2; i >= 0; i--) {
			noOfZeroes[i] = noOfZeroes[i + 1];
			if (arr[i] == 0)
				noOfZeroes[i]++;
		}

		// Count total number of swaps by adding number
		// of zeroes on right side of every one.
		for (i = 0; i < n; i++) {
			if (arr[i] == 1)
				count += noOfZeroes[i];
		}
		return count;
	}

	static int minMoves1(List<Integer> a) {
		int n = a.size();
		Integer[] arr = new Integer[n];
		arr = a.toArray(arr);
		int noOfZeroes[] = new int[n];
		int i, count = 0;
//		Integer[] decArr=arr;
//		Arrays.sort(decArr);
//		if (decArr==arr) {
//			return 0;
//		}
		// Count number of zeroes
		// on right side of every one.
		noOfZeroes[n - 1] = 1 - arr[n - 1];
		for (i = n - 2; i >= 0; i--) {
			noOfZeroes[i] = noOfZeroes[i + 1];
			if (arr[i] == 0)
				noOfZeroes[i]++;
		}

		// Count total number of swaps by adding number
		// of zeroes on right side of every one.
		for (i = 0; i < n; i++) {
			if (arr[i] == 1)
				count += noOfZeroes[i];
		}
		return count;
	}

	// Driver Program
	public static void main(String[] args) {
//		int arr[] = { 0, 1, 0, 1 };
//		int n = arr.length;
//		System.out.println(minMoves(arr, n));
//		
		Integer arr[] = { 1, 1, 1, 1, 0, 0, 0, 0 };
		System.out.println(minMoves1(Arrays.asList(arr)));

	}
}

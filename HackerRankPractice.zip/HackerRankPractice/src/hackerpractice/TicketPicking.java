package hackerpractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TicketPicking {

	static int solution1(int[] a) {

		int count = 1, temp = 0;
		for (int i = 0; i < a.length - 1; i++) {
			if (a[i + 1] - a[i] == 0 || a[i + 1] - a[i] == 1) {
				count++;
			} else {
				count = 1;
			}
//			if (temp < count) {
//				temp = count;
//
//			}
			temp=Math.max(temp, count);
		}
		return temp;
	}

	static int solution(int[] a) {
		List<Integer> list = new ArrayList<Integer>();
		Map<Integer, List<Integer>> map = new HashMap<Integer, List<Integer>>();
		int num = a[0];
		list.add(num);
		int count = 0;
		for (int i = 1; i < a.length; i++) {
			int x = a[i];
			if (x - num == 0 || x - num == 1) {
				if (map.get(count) == null) {
					list.add(x);
					map.put(count, list);
				} else
					map.get(count).add(x);
			} else {
				count++;
				List list1 = new ArrayList();
				list1.add(x);
				if (map.get(count) == null) {
					map.put(count, list1);
				} else
					map.get(count).add(x);
			}
			num = x;

		}
//		System.out.println(list);
//		System.out.println(map);
		Collection<List<Integer>> values = map.values();
		int size = 0;
		Iterator<List<Integer>> it = values.iterator();
		while (it.hasNext()) {
			List<java.lang.Integer> list2 = (List<java.lang.Integer>) it.next();
			if (size < list2.size()) {
				size = list2.size();
			}

		}
		return size;
	}

	public static void main(String[] args) {
		int[] a = { 1, 2, 3, 4, 5, 14, 17, 16, 15 };
		Arrays.sort(a);
		System.out.println(solution1(a));
	}

}

package com.hcl.service;

import java.util.List;
import java.util.Optional;

import com.hcl.model.Hangar;

public interface HangarService {

    List<Hangar> getALLHangars();

    Optional<Hangar> findHangarById(String hangarId);

}

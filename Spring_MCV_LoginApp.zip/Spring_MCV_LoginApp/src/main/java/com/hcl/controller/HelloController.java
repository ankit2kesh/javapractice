//package com.hcl.controller;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.servlet.ModelAndView;
//
//@Controller
//public class HelloController {
//	@RequestMapping("/")
//	public String index() {
//		System.out.println("indexsssssss.......");
//		return "index";
//	}
//
//	@RequestMapping("/hello")
//	public String redirect() {
//		System.out.println("hello.......");
//		return "viewpage";
//	}
//
//	@RequestMapping("/helloagain")
//	public ModelAndView display() {
//		return new ModelAndView("final");
//	}
//}

package com.hcl.service;

import java.util.List;

import com.hcl.model.Employee;

public interface EmployeeServiceInterface {
	void saveData(Employee employee);

	void saveOrData(Employee employee);

	void delete(int id);

	List<Employee> readAll();
}

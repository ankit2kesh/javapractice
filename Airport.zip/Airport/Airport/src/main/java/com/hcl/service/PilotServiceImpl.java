package com.hcl.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.PilotDao;
import com.hcl.model.Pilot;

@Service
@Transactional
public class PilotServiceImpl implements PilotService {
    
    @Autowired
    private PilotDao pilotDao;

    @Override
    public List<Pilot> getAllPilots() {
        return pilotDao.getAllPilots();
    }

    @Override
    public Optional<Pilot> findPilotById(String pilotID) {
        return pilotDao.findPilotById(pilotID);
    }

}

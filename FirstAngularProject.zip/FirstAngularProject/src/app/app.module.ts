import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { CountComponent } from './count/count.component';
import { CounterComponent } from './counter/counter.component';
import { ContainerComponent } from './container/container.component';
import { CartListComponent } from './cart-list/cart-list.component';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import {ColoringDirective} from './Directives/coloringDirective';
import { ColoringAltDirective } from './Directives/coloring-alt.directive';
import { Logger } from './service/logger.service';
import { SqrtPipe } from './pipes/app.sqrt';
import { FormComponent } from './form/form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
@NgModule({
  declarations: [
    AppComponent,
    ContactusComponent,
    HomeComponent,
    RegistrationComponent,
    LoginComponent,
    CountComponent,
    CounterComponent,
    ContainerComponent,
    CartListComponent,
    AboutComponent,
    ServicesComponent,
    ColoringDirective,
    ColoringAltDirective,
    SqrtPipe,
    FormComponent,
    ReactiveFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [Logger],
  bootstrap: [AppComponent]
})
export class AppModule { }

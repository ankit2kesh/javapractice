
package com.hcl.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.Hangar;
import com.hcl.model.Pilot;
import com.hcl.model.Plane;
import com.hcl.service.AdminService;

@Controller
public class AdminController {
    
    @Autowired
    private AdminService adminService;
    
    @RequestMapping("ViewManagers")
    public ModelAndView showManagers() {
        return new ModelAndView("Managers");
    }
    
    @PostMapping(value = "/AddPlane" , consumes = MediaType.APPLICATION_JSON_VALUE)
    public Plane addPlane(@RequestBody @Valid Plane plane) {
        return adminService.addPlane(plane) ;
    }
    @PostMapping(value = "/AddPilot", consumes = MediaType.APPLICATION_JSON_VALUE)
    public Pilot addPilot(@RequestBody @Valid Pilot pilot) {
        return adminService.addPilot(pilot);
    }
    @PostMapping(value = "/Addhangar", consumes = MediaType.APPLICATION_JSON_VALUE)
    public Hangar addHanagr(@RequestBody @Valid Hangar hangar) {
        return adminService.addHangar(hangar);
    }

}

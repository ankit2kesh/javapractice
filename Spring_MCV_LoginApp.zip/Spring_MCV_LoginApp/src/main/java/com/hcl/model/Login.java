package com.hcl.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
//import org.hibernate.validator.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "login_app")
public class Login {
//	@NotEmpty(message = "Please enter ur username")
	private String username;
//	@NotEmpty(message = "Please enter ur password")
	private String password;
}

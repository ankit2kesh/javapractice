// let emp: Employee;
// let empName: string;
// emp.FirstName = "Angular";
// emp.LastName = "TypeScript";
var emp1;
emp1 = "asdasd";
emp1 = { age: 12, gender: "Female" };
// const Emp: {
//     FirstName: string,
//     LastName: string,
//     age: number
// } = {
//     FirstName: "Angular",
//     LastName: "Typescript",
//     age: 23
// }
// const Emp: {
//     FirstName: string,
//     LastName: string,
//     CityOfTravel: string[],
//     FavTravelMonth: [number, string]
// } = {
var Emp = {
    FirstName: "Angel",
    LastName: "Heaven",
    CityOfTravel: ['India', 'Australia', 'canada'],
    FavTravelMonth: [1, 'March']
};
var Role;
(function (Role) {
    Role[Role["HR"] = 101] = "HR";
    Role[Role["ITI"] = 102] = "ITI";
    Role[Role["Admin"] = 103] = "Admin";
    Role[Role["Infra"] = 104] = "Infra";
})(Role || (Role = {}));
// const HR = 102;
// const IT = 103;
console.log(Role);
console.log(Emp.FavTravelMonth);
Emp.FavTravelMonth = ['June', 'July', "August"];
console.log(Emp.FavTravelMonth);
Emp.CityOfTravel.push('USA');
Emp.CityOfTravel.map(function (item) { console.log(item); });
Emp.CityOfTravel.pop();
console.log(Emp.CityOfTravel);
var favourites;
favourites = ['Rome', 'Finland'];
console.log(favourites);
for (var _i = 0, favourites_1 = favourites; _i < favourites_1.length; _i++) {
    var fav = favourites_1[_i];
    console.log(fav);
}
// console.log(Employee.FirstName + Employee.LastName);
// const emp = {};
var alpha = ["a", "b", "c"];
var numeric = ["1", "2", "3"];
var alphaNumeric = alpha.concat(numeric);
console.log("alphaNumeric : " + alphaNumeric);
var num = [7, 8, 9];
num.forEach(function (value) {
    console.log(value);
});
var index = [12, 5, 8, 130, 44].indexOf(8);
console.log("index is : " + index);
var arr = new Array("First", "Second", "Third");
var str1 = arr.join();
console.log("str1 : " + str1);
var str2 = arr.join(", ");
console.log("str2 : " + str2);
var str3 = arr.join(" + ");
console.log("str3 : " + str3);
var index1 = [12, 5, 8, 130, 44].lastIndexOf(8);
console.log("index is : " + index);
var numbers = [1, 4, 9];
var roots = numbers.map(Math.sqrt);
console.log("roots is : " + roots);
var arr1 = ["orange", "mango", "banana", "sugar", "tea"];
console.log("arr.slice( 1, 2) : " + arr1.slice(1, 2));
console.log("arr.slice( 1, 3) : " + arr1.slice(1, 3));
var arr2 = new Array("orange", "mango", "banana", "sugar");
var sorted = arr2.sort();
console.log("Returned string is : " + sorted);
var arr3 = new Array("orange", "mango", "banana", "sugar");
var length1 = arr3.unshift("water");
console.log("Returned array is : " + arr3);
console.log("Length of the array is : " + length1);
var total = [0, 1, 2, 3].reduce(function (a, b) { return a + b; });
console.log("total is : " + total);
var numbers1 = new Array(1, 4, 9);
var length = numbers1.push(10);
console.log("new numbers is : " + numbers1);
length = numbers1.push(20);
console.log("new numbers is : " + numbers1);
var numbers2 = [1, 4, 9];
var element = numbers2.pop();
console.log("element is : " + element);
var element = numbers2.pop();
console.log("element is : " + element);
var obj = {
    Name: "Angular",
    Duration: "2hr",
    Week: "4 weeks"
};
// const{Name, Duration}=obj
var _a = [10, 20, 30, 40, 44, 37], a = _a[0], b = _a[1], rest = _a.slice(2);
console.log(a);
console.log(b);
console.log(rest);

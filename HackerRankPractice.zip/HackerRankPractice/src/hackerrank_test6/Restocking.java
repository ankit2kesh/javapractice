package hackerrank_test6;

import java.util.Arrays;
import java.util.List;

public class Restocking {
	public static int restock(List<Integer> itemCount, int target) {
	    // Write your code here
	        int sum=0;
	        for(int s:itemCount){
	            if(s==target){
	                return s;
	            }else if(sum<target){
	                sum=sum+s;
	            }
	        }
	        if(sum<target){
	            sum=target-sum;
	        }else if(sum>target){
	            sum=sum-target;
	        }
	        return sum;
	    }
	public static void main(String[] args) {
		Integer[] a={1,2,3,2,1};
		int result=restock(Arrays.asList(a), 4);
		System.out.println(result);
	}

}

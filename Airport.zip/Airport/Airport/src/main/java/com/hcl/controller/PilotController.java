package com.hcl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.model.Pilot;
import com.hcl.model.Plane;
import com.hcl.service.PilotService;

@RestController
public class PilotController {
    
    @Autowired
    private PilotService pilotService;
    
    @GetMapping(value = "/getAllPilots" ,produces =MediaType.APPLICATION_JSON_VALUE)
    public List<Pilot> getAllPilots(){
        return pilotService.getAllPilots();
    }
    
    @GetMapping(value = "/getPilotById/{pilotID}" ,produces =MediaType.APPLICATION_JSON_VALUE)
    public Optional<Pilot> getPilotById(@PathVariable(name ="pilotID") String pilotID ){
        return pilotService.findPilotById(pilotID);
    }
    
    @PostMapping(value = "/updatePilot/{pilotID}/{pilotName}")
    public Plane updatePlaneDetails(@PathVariable(name ="pilotID" ,required = false)String pilotID
            ,@PathVariable(name ="pilotName",required = false)String pilotName){
        return null;
        
    }

}

package hackerrank_test6;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DamDesign {
	public static int maxHeight1(List<Integer> wallPositions, List<Integer> wallHeights) {
		int result = 0;
		for (int i = 0; i < wallPositions.size() - 1; i++) {
			if (wallPositions.get(i) < wallPositions.get(i + 1) - 1) {
				int hd = Math.abs(wallHeights.get(i + 1) - wallHeights.get(i));
				int gap = wallPositions.get(i + 1) - wallPositions.get(i) - 1;
				int max = 0;
				if (gap > hd) {
					int x = Math.max(wallHeights.get(i + 1), wallHeights.get(i)) + 1;
					int rem = gap - hd - 1;
					max = x + rem / 2;
				} else {
					max = Math.min(wallHeights.get(i + 1), wallHeights.get(i)) + gap;
				}
				result = Math.max(result, max);
			}
		}
		return result;
	}

	public static int maxHeight(List<Integer> wallPositions, List<Integer> wallHeights) {
		int result = 0;
		for (int i = 0; i < wallPositions.size() - 1; i++) {
			if (wallPositions.get(i) < wallPositions.get(i + 1) - 1) {
				int gapBetWalls = wallPositions.get(i + 1) - wallPositions.get(i) - 1;
				System.out.println("no of mud segments can be made can be made between "+wallPositions.get(i)+" and "+wallPositions.get(i+1)+" is : " + gapBetWalls);
//				int heightDifference = Math.abs(wallHeights.get(i + 1) - wallHeights.get(i));
//				System.out.println("Height deifference between the walls : " + heightDifference);
				System.out.println("Height of wall positions "+wallPositions.get(i)+" is "+wallHeights.get(i)+" and "+wallPositions.get(i+1)+" is "+wallHeights.get(i + 1));
				int max = Math.min(wallHeights.get(i + 1), wallHeights.get(i)) + gapBetWalls;
				System.out.println("max height of the mud segment : " + max);
				result = Math.max(result, max);
			}
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] a = { 1, 2, 4, 7 };
		Integer[] b = { 4, 6, 8, 11 };
//		Integer[] a = { 1, 3, 8 };
//		Integer[] b = { 4, 6, 3 };
		System.out.println(maxHeight(Arrays.asList(a), Arrays.asList(b)));

	}

}

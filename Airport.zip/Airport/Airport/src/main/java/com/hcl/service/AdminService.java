package com.hcl.service;

import com.hcl.model.Hangar;
import com.hcl.model.Pilot;
import com.hcl.model.Plane;

public interface AdminService {

    Plane addPlane(Plane plane);

    Pilot addPilot(Pilot pilot);

    Hangar addHangar(Hangar hangar);

}

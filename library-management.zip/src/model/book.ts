export class Book{
    id: number = 0;
    title: string = '';
    author: string = '';
    description: string = '';
    rackNumber: number = 0;
    numberOfCopy: number = 0;
    constructor() { 
    }
}
package com.hcl.service;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.hcl.model.Login;

public interface LoginServiceInterface {

	void saveData(Login login) throws UnsupportedEncodingException;

	List<Login> fetchAll();

	Login fetchById(int id);
}

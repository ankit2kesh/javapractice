package com.hcl;

public class BitCount {

	public static int countOne(int a, int b) {
		int product = a * b;
		return Integer.bitCount(product);
	}

	public static void main(String[] args) {
		System.out.println(countOne(3, 7));
	}

}

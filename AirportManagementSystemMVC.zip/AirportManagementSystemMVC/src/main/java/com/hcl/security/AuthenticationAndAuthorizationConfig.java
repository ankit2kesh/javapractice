package com.hcl.security;

import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;

@EnableWebMvcSecurity
public class AuthenticationAndAuthorizationConfig extends WebSecurityConfigurerAdapter {

	public void configure(AuthenticationManagerBuilder auth) throws Exception

	{
		auth.jdbcAuthentication().dataSource(dataSource())
				.usersByUsernameQuery("select username,password,1 as enabled from users where username=?")
				.authoritiesByUsernameQuery("select username,authority from authorities  where username=?");
//	.authoritiesByUsernameQuery(
//			"select u.user_id, ur.authority from user_details u, user_authority ur where u.id = ur.id and u.user_id = ?");
		// auth.inMemoryAuthentication().withUser("revathi").password("reva").roles("ADMIN");
//	auth.inMemoryAuthentication().withUser("drish").password("drish").roles("USER");

	}

	public void configure(HttpSecurity http) throws Exception {
		http.csrf().disable();
		http.authorizeRequests().antMatchers("/Success").access("hasRole('ROLE_USER')")
				.antMatchers("/Admin").access("hasRole('ADMIN')").and().formLogin().loginPage("/loginPage")
				.successHandler(new CustomHandler()).failureUrl("/loginPage?error").and().exceptionHandling()
				.accessDeniedPage("/403");
	}

	public DriverManagerDataSource dataSource() {
		DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
		driverManagerDataSource.setDriverClassName("com.mysql.jdbc.Driver");
		driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/test");
		driverManagerDataSource.setUsername("root");
		driverManagerDataSource.setPassword("root");
		return driverManagerDataSource;
	}
}

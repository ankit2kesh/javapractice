package com.hcl.dao;

import com.hcl.model.Login;

public interface LoginDaoInterface {
	void saveData(Login login);

	void fetchAll();

	void fetchById(int id);
}

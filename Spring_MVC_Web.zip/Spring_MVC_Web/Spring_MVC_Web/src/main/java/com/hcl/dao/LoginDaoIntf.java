package com.hcl.dao;

import java.util.List;

import com.hcl.model.Login;

public interface LoginDaoIntf {

	void saveData(Login login);

	List<Login> fetchAll();

	Login fetchById(int id);
}

package com.hcl.repo;

import org.springframework.data.repository.CrudRepository;

import com.hcl.model.Employee;
public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

}

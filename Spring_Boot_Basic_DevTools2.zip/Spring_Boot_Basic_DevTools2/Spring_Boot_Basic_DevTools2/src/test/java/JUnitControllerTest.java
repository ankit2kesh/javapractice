import static org.junit.Assert.assertEquals;

import org.junit.Test;

import main.controller.sampleController;
import main.model.Employee;

public class JUnitControllerTest {

    @Test
    public void testHomeController() {
        sampleController homeController = new sampleController();
        String result = homeController.empform(new Employee());
        assertEquals(result, "addForm");
    }
}
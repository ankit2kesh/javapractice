
package com.hcl.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.RegisterUser;
import com.hcl.model.User;
import com.hcl.repository.RegisterUserRepository;
import com.hcl.repository.UserRepository;

@Repository
public class RegisterDaoImpl implements RegisterDao {

	@Autowired
	private RegisterUserRepository registerUserRepository;
	@Autowired
	private UserRepository userRepository;

	public RegisterUser saveUser(RegisterUser registerUser) {
		User u = new User();
		u.setUsername(registerUser.getUsername());
		u.setPassword(registerUser.getPassword());
		u.setRoles(registerUser.getUserRole());
		userRepository.save(u);
		return registerUserRepository.save(registerUser);
	}

}

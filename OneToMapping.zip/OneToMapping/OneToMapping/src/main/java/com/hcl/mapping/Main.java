package com.hcl.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		try {
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");// cfg.xml,hbm.xml
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
			Address address = new Address();
			address.setCity("Chennai");
			address.setStreet("VGN");
			session.save(address);
			Student student = new Student();
			student.setName("Revathi");
			student.setAddress(address);
			session.save(student);
			tx.commit();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}

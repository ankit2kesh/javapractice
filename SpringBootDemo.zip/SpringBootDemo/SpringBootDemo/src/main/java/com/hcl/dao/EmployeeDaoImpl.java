package com.hcl.dao;

import java.util.List;
import java.util.Optional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDaoInterface {
	@Autowired
	SessionFactory sf;

	public void saveData(Employee employee) {
		System.out.println("save dao :" + employee.getName());
		sf.openSession().save(employee);
	}

	@Transactional
	public void saveOrData(Employee employee) {
		System.out.println("saveOrUpdate dao :" + employee.getName());
		sf.openSession().saveOrUpdate(employee);
	}

	@Transactional
	public void delete(int id) {
		System.out.println("delete dao :" + id);
		Session s = sf.openSession();
		Query<Employee> q = s.createQuery("from Employee where id=:id");
		q.setParameter("id", id);
		Optional<Employee> option = q.uniqueResultOptional();
		System.out.println("optional : " + option);
		Employee emp = null;
		if (option.isPresent()) {
			emp = option.get();
			System.out.println("emp : " + emp.getCity());
			s.delete(emp);
		}
//		sf.openSession().delete(employee);

	}

	public List<Employee> readAll() {
		Query<Employee> q = sf.openSession().createQuery("from Employee");
		List<Employee> listAll = q.list();
		return listAll;
	}
}

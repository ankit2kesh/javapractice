
package com.hcl.dao;

import com.hcl.model.User;


public interface RegisterDao {

    public User saveUser(User regAdmin);


}

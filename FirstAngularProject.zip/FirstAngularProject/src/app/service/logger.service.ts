export class Logger{
    count:number=0;
    consoleLogger(msg){
        this.count=this.count+1;
        console.log(msg+" "+this.count);
    }
}
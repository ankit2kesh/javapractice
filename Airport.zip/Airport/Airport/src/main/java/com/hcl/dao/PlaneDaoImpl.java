package com.hcl.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Plane;
import com.hcl.repository.PlaneRepository;

@Repository
public class PlaneDaoImpl implements PlaneDao{
    
    @Autowired
    private PlaneRepository planeRepo;

    @Override
    public List<Plane> getAllPlanes() {
        return planeRepo.findAll();
    }

    @Override
    public Optional<Plane> findPlaneById(String planeID) {
        return planeRepo.findById(Integer.parseInt(planeID));
    }

}

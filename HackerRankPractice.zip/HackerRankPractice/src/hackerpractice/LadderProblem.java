package hackerpractice;

public class LadderProblem {
	public static int[] solution(int[] A, int[] B) {
		int[] L = new int[A.length];
		for (int i = 0; i < A.length; i++) {
			L[i] = A[i] % (2 ^ B[i]);
		}
		int[] temp = new int[A.length];
		for (int i = 0; i < temp.length; i++) {
			temp[i] = A[i] % (1 << B[i]);
		}
		return temp;
	}

	public static int[] solution1(int[] A, int[] B) {
		int len = A.length;
		int[] ladder = new int[len];
		if (A != null && B != null && (A.length == B.length)) {
			int fib[] = new int[len + 1];
			fib[0] = 1;
			fib[1] = 1;
			for (int i = 2; i < len + 1; ++i)
				fib[i] = (fib[i - 1] + fib[i - 2]) % (1 << 30);
			for (int i = 0; i < len; ++i)
				ladder[i] = fib[A[i]] % (1 << B[i]);
		}
		return ladder;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = { 4, 4, 5, 5, 1 };
		int[] b = { 3, 2, 4, 3, 1 };
		int[] result = solution1(a, b);
		for (int r : result)
			System.out.println(r + " ");

	}

}


package com.hcl.dao;

import com.hcl.model.Login;

public interface LoginDao {

	public Login saveData(Login login);

}

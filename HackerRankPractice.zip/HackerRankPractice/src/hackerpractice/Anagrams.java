package hackerpractice;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Anagrams {

	public static void main(String[] args) {
		List<String> l=Arrays.asList("code","doce","lamp","jako");
		Collection list=groupAnagrams(l);
		System.out.println(list);

	}
	public static Collection<LinkedList<String>> groupAnagrams(List<String> words) {
	    Map<String, LinkedList<String>> anagramMap = new HashMap<>();
	    for(String word : words) {
	        char[] wordChars = word.toCharArray();
	        Arrays.sort(wordChars);
	        String sortedKey = new String(wordChars);
	        LinkedList<String> anagramList = anagramMap.get(sortedKey);
	        if(anagramList == null) {
	            anagramMap.put(sortedKey, anagramList = new LinkedList<>());
	        }
	        anagramList.add(word);
	    }
	    return anagramMap.values();
	}
	public static int reduceCapacity1(List<Integer> model) {
		float halfSize = model.size() / 2;
		if (model.size() % 2 != 0) {
			halfSize++;
		}
		Collections.sort(model);
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < model.size(); i++) {
			Integer intg = map.get(model.get(i));
			if (intg == null) {
				map.put(model.get(i), 1);
			} else {
				map.put(model.get(i), intg + 1);
			}
		}
		map = map.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
				.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> null, // or throw an exception
						() -> new LinkedHashMap<Integer, Integer>()));
		int result = 0;
		int resultSum = 0;
		System.out.println("" + map);
		for (Map.Entry<Integer, Integer> val : map.entrySet()) {
			if (halfSize > resultSum) {
				resultSum = resultSum + val.getValue();
				result++;
			}
		}
		return result;
	}

}

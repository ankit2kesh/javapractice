package com.hcl;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

public class Test {

	public static void main(String[] args) {
		List l= new ArrayList();
		l.add(2);
		l.add(2);
		l.add("ankit");
		l.add("ankit");
		System.out.println(l);
		StringBuffer sb=new StringBuffer("ABCDE");
		sb.setCharAt(3, 'X');
		System.out.println(sb);
		
		TreeMap<Integer, String> tm=new TreeMap<Integer, String>();
		tm.put(2, "two");
		tm.put(4, "four");
		tm.put(1, "one");
		tm.put(6, "six");
		tm.put(7, "seven");
		SortedMap<Integer, String> sm=tm.subMap(2, 7);
		SortedMap<Integer, String> sm1=sm.tailMap(4);
		System.out.println(sm1);
		
	}

}

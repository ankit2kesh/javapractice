package hackerrank_test4;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class RodCut {
	public static List<Integer> rodOffcut(List<Integer> lengths) {
		Collections.sort(lengths);
		List<Integer> list = new LinkedList<Integer>();
		while (lengths.size() != 0) {
			list.add(lengths.size());
			lengths = cutLength(lengths);
		}
		return list;
	}

	public static List<Integer> cutLength(List<Integer> lengths) {
		int small = lengths.get(0);
		List<Integer> list = new LinkedList<Integer>();
		for (int i = 0; i < lengths.size(); i++) {
			if (lengths.get(i) - small > 0)
				list.add(lengths.get(i) - small);
		}
		return list;
	}

	public static List<Integer> rodOffcut1(List<Integer> lengths) {
		Collections.sort(lengths);

		List<Integer> list = new LinkedList<Integer>();
		while (lengths.size() != 0) {
			list.add(lengths.size());
			int min = lengths.get(0);
			List<Integer> list1 = new LinkedList<Integer>();
			for (Integer integer : lengths) {
				if (integer - min > 0) {
					list1.add(integer - min);
				}

			}
			lengths = list1;

		}
		return list;
	}

	public static void main(String[] args) {
		Integer[] a = { 1, 1, 3, 4 };
		System.out.println(rodOffcut1(Arrays.asList(a)));

	}

}

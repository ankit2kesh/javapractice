package com.hcl.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Managers {
	private int id;
	private String username;
	private String password;
	private boolean active = false;
	private String roles;
}

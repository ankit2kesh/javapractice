package hackerpractice;

public class Test {
	static int solution(int a, int b) {
		String s = String.valueOf(b);
		for (int i = 0; i < s.length() - 1; i++) {
			String x = s.charAt(i) + "" + s.charAt(i + 1);
			int y = Integer.parseInt(x);
			if (a == y) {
				return i;
			}
		}

		return -1;
	}

	static int solution1(int a, int b) {
		String s1 = Integer.toString(a);
		String s2 = Integer.toString(b);
		if (s2.contains(s1)) {
			return s2.indexOf(s1);
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(solution(78, 195378678));
	}

}

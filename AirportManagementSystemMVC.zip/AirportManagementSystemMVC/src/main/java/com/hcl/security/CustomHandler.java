package com.hcl.security;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
/*import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;*/
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

//https://javadeveloperzone.com/spring-boot/spring-security-custom-success-or-fail-handler/
public class CustomHandler implements AuthenticationSuccessHandler {

	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication auth)
			throws IOException, ServletException {
		User user = (User) auth.getPrincipal();
		Collection<GrantedAuthority> ls = user.getAuthorities();
		Iterator<GrantedAuthority> itr = ls.iterator();
		while (itr.hasNext()) {

			if ((itr.next().getAuthority().equalsIgnoreCase("ROLE_ADMIN"))) {
				response.sendRedirect("/Admin");
			} else {
				response.sendRedirect("/Success");
			}
		}
	}
}

package main.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import main.model.Employee;
import main.service.EmployeeServiceIntf;

@RestController
public class sampleController {
	@Autowired
	EmployeeServiceIntf esi;

	@RequestMapping(value = "/newEmployee")
	public String empform(@ModelAttribute("employee") Employee employee) {
		return "addForm";
	}

	@PostMapping(value = "/save")
	public ModelAndView saveData(@RequestBody Employee employee) {
		esi.saveData(employee);
		return new ModelAndView("Success");
	}

	@RequestMapping(value = "/findById/{id}")
	public Employee fetchById(@PathVariable("id") int id) {

		Employee emp = esi.fetchById(id);
		return emp;
	}

	@GetMapping(value = "/read")
	public List<Employee> readAll() {

		return esi.readAll();
	}

	@DeleteMapping(value = "/delete/{id}")
	public void deleteById(@PathVariable("id") int id) {

	}

	/*
	 * @PutMapping(value = "/update") public Employee updateUser(@Valid @RequestBody
	 * Employee emp) { return esi.updateUser(emp); }
	 */

}

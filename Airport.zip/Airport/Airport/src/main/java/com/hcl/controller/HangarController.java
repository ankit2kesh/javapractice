package com.hcl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.model.Hangar;
import com.hcl.service.HangarService;

@RestController
public class HangarController {
    
    @Autowired
    private HangarService hangarService;
    
    @GetMapping(value = "/getAllHangars" , produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Hangar> getALLHangars(){
        return hangarService.getALLHangars();
        
    }
    
    @GetMapping(value = "/gethangarById/{hangarId}" , produces = MediaType.APPLICATION_JSON_VALUE)
    public Optional<Hangar> findHangarById(@PathVariable( name = "hangarId")String hangarId){
        return hangarService.findHangarById(hangarId);
        
    }

}

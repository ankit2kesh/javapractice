package hackerpractice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SemiPrimes {
	public static Integer[] solution(int N, int[] P, int[] Q) {
		int count = 0;
		List list = new ArrayList();

		for (int i = 2; i <= N / 2; i++) {
			count = 0;
			for (int j = 2; j <= i / 2; j++) {
				if (i % j == 0) {
					count++;
					break;
				}
			}

			if (count == 0) {
				list.add(i);
			}

		}
		System.out.println(list);
		List semiPrimeList = new ArrayList();
		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < list.size(); j++) {
				if ((int) list.get(i) * (int) list.get(j) <= N
						&& !semiPrimeList.contains((int) list.get(i) * (int) list.get(j))) {
					semiPrimeList.add((int) list.get(i) * (int) list.get(j));
				}
			}
		}
		Collections.sort(semiPrimeList);
		System.out.println(semiPrimeList);
		List resultList = new ArrayList();

		for (int i = 0; i < Q.length; i++) {
			int semiPrimeCount = 0;
			for (int j = 0; j < semiPrimeList.size(); j++) {
				if ((int) semiPrimeList.get(j) >= P[i] && (int) semiPrimeList.get(j) <= Q[i]) {
					semiPrimeCount++;
				}
			}
			resultList.add(semiPrimeCount);
		}
		System.out.println(resultList);
		Integer[] result = (Integer[]) resultList.toArray(new Integer[resultList.size()]);
		return result;
	}

	public static void main(String[] args) {
		int[] p = { 1, 4, 16 };
		int[] q = { 26, 10, 20 };
		int n = 26;
		Integer[] result = solution(n, p, q);
		for (int i : result)
			System.out.print(i + " ");

	}

}

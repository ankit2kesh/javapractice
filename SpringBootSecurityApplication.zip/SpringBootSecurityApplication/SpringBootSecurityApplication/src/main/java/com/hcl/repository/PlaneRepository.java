package com.hcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.model.Plane;

public interface PlaneRepository extends JpaRepository<Plane, Integer>{

}

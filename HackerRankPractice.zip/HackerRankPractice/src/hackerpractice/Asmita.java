package hackerpractice;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;

public class Asmita {
	static int solution(String S) {
        Stack<Character> stack = new Stack<Character>();
        for (int i = 0; i < S.length(); i++) {
            char pointer = S.charAt(i);
            if (pointer == '[' || pointer == '{' || pointer == '(') {
                stack.push(pointer);
            }
            if(stack.isEmpty())return 0;
            switch (pointer) {
            case ')':
                if (stack.peek() == '{' || stack.peek() == '[')
                    return 0;
                else
                    stack.pop();
                break;
            case '}':
                if (stack.peek() == '(' || stack.peek() == '[')
                    return 0;
                else
                    stack.pop();
                break;
            case ']':
                if (stack.peek() == '{' || stack.peek() == '(')
                    return 0;
                else
                    stack.pop();
                break;
            }
        }
        return stack.isEmpty()?1:0;
    }
	public static String solution(String s, int[] A) {
		String result="";
		LinkedList l=new LinkedList();
		for (int i = 0; i < A.length; i++) {
			l.add(s.charAt(i));
		}		
		result+=l.poll();
		result+=l.pollLast();
		result+=l.poll();
		result+=l.pollLast();
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="cdeo";//eodc
		int[] a= {3,2,0,1};
		System.out.println(solution(s, a));
	}

}

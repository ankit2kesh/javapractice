package main.dao;

import java.util.List;

import main.model.Employee;

public interface EmployeeDaoIntf<E> {

	void saveData(Employee employee);

	Employee fetchById(int id);

	List<E> fetchAll();

	public void deleteById(int id);
}

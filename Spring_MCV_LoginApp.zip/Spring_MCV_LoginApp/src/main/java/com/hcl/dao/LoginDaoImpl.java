package com.hcl.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Login;

@Repository
public class LoginDaoImpl implements LoginDaoInterface {

	@Autowired
	SessionFactory sessionFactory;

	public void saveData(Login login) {
		System.out.println("hello2");
		sessionFactory.openSession().save(login);

	}

	public List<Login> fetchAll() {
		Query q = sessionFactory.getCurrentSession().createQuery("from Login");
		List ls = q.list();
		return ls;
	}

	public Login fetchById(int id) {
		Login l = (Login) sessionFactory.getCurrentSession().createQuery("from Login where id='" + id + "'")
				.uniqueResult();
		return l;
	}
}

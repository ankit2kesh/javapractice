package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.model.Employee;
import com.example.repo.EmployeeRepository;
import com.example.util.Util;

@Service
@Transactional
public class EmployeeServiceImpl {
	@Autowired
	EmployeeRepository er;
	@Autowired
	Util u;

	public void add(Employee e) {
		u.util();
		er.save(e);
	}
}


package com.hcl.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.User;
import com.hcl.repository.UserRepository;

@Repository
public class RegisterDaoImpl implements RegisterDao {

	@Autowired
	private UserRepository userRepository;

	public User saveUser(User register) {
		return userRepository.save(register);
	}

}

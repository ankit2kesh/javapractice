package com.hcl.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Hangar;
import com.hcl.repository.HangarRepository;

@Repository
public class HangarDaoImpl implements HangarDao {
    
    @Autowired
    private HangarRepository hangarRepo;

    @Override
    public List<Hangar> getALLHangars() {
        return hangarRepo.findAll();
    }

    @Override
    public Optional<Hangar> findHangarById(String hangarId) {
        return hangarRepo.findById(Integer.parseInt(hangarId));
    }

}

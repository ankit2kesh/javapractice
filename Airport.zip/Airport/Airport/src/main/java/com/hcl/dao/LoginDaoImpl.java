
package com.hcl.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Login;
import com.hcl.repository.LoginRepository;
import com.hcl.repository.UserRepository;


@Repository
public class LoginDaoImpl implements LoginDao {

    @Autowired
    private LoginRepository loginRepository;

    public Login saveData(Login login) {
        return loginRepository.save(login);

    }

}

package com.hcl;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Employee {
	private int id;
	private String name;
	private float salary;

	public Employee(int id, String name, int salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
}

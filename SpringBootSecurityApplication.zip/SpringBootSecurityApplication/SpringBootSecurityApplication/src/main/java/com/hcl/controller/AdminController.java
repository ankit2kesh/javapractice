
package com.hcl.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.Hangar;
import com.hcl.model.Pilot;
import com.hcl.model.Plane;
import com.hcl.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	private AdminService adminService;

	@RequestMapping("ViewManagers")
	public ModelAndView showManagers() {
		return new ModelAndView("Managers");
	}

	@RequestMapping(value = "/AddPlane")
	public ModelAndView addPlane() {
		return new ModelAndView("AddPlane");
	}

	@RequestMapping(value = "/SavePlane")
	public ModelAndView savePlane(Plane plane) {
		System.out.println("plane : " + plane);
		adminService.addPlane(plane);
		return new ModelAndView("AdminHome");
	}

	@RequestMapping(value = "/AddPilot")
	public ModelAndView addPilot(Pilot pilot) {
		return new ModelAndView("AddPilot");
	}

	@RequestMapping(value = "/SavePilot")
	public ModelAndView savePilot(Pilot pilot) {
		adminService.addPilot(pilot);
		return new ModelAndView("AdminHome");
	}

	@RequestMapping(value = "/Addhangar")
	public ModelAndView addHanagr(Hangar hangar) {
		return new ModelAndView("Addhangar");
	}

	@RequestMapping(value = "/Savehangar")
	public ModelAndView saveHanagr(Hangar hangar) {
		adminService.addHangar(hangar);
		return new ModelAndView("AdminHome");
	}

}

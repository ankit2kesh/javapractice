package com.hcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.model.RegisterUser;

public interface RegisterUserRepository extends JpaRepository<RegisterUser, Integer> {

}


package com.hcl.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class DelegatingFilterProxyConfig extends AbstractSecurityWebApplicationInitializer{
public DelegatingFilterProxyConfig()
{
	super(AuthenticationAndAuthorizationConfig.class);
}
}

package hackerrank_test4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CardinalitySorting {
	public static List<Integer> cardinalitySort1(List<Integer> nums) {
		Collections.sort(nums, new Comparator<Integer>() {

			@Override
			public int compare(Integer num1, Integer num2) {
				int result = 0;
				if (num1 == num2) {
					result = 0;
				} else if (Integer.bitCount(num1) < Integer.bitCount(num2)) {
					result = -1;
				} else if (Integer.bitCount(num1) > Integer.bitCount(num2)) {
					result = 1;
				} else if (Integer.bitCount(num1) == Integer.bitCount(num2)) {
					result = (num1 > num2) ? 1 : -1;
				}
				return result;
			}
		});
		return nums;
	}

	public static int[] cardinalitySort(int[] nums) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < nums.length; i++) {
			for (int j = i+1; j < nums.length; j++) {
				if (Integer.bitCount(nums[i]) > Integer.bitCount(nums[j])) {
					int temp = nums[i];
					nums[i] = nums[j];
					nums[j] = temp;
				}
			}
			

		}
		for (int i = 0; i < nums.length; i++) {
			System.out.print(nums[i]+" ");
		}
		return nums;
	}

	public static void main(String[] args) {
		int[] a = { 5, 2, 3, 4, 1 };
		Arrays.parallelSort(a);
		System.out.println(cardinalitySort(a));

	}

}

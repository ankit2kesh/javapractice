package main.dao;

import java.util.function.Supplier;

public class EmployeeIdNotFoundException extends Throwable implements Supplier {
String str;
    public EmployeeIdNotFoundException(String string){
        str=string;
      }
    
    public String toString() {
        return str;
      
        
    }

    @Override
    public Object get() {
        // TODO Auto-generated method stub
        return null;
    }

   
    }



package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Employee;
import com.example.service.EmployeeServiceImpl;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeServiceImpl esi;

	@RequestMapping("hello")
	public String home() {
		return "home";
	}

	@RequestMapping("add")
	public String add(@RequestBody Employee e) {
		esi.add(e);
		return "success";
	}
}

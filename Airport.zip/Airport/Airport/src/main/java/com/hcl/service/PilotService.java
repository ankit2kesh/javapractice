package com.hcl.service;

import java.util.List;
import java.util.Optional;

import com.hcl.model.Pilot;

public interface PilotService {

    List<Pilot> getAllPilots();

    Optional<Pilot> findPilotById(String pilotID);

}

package com.hcl.dao;

import java.util.List;
import java.util.Optional;

import com.hcl.model.Pilot;

public interface PilotDao {

    List<Pilot> getAllPilots();

    Optional<Pilot> findPilotById(String pilotID);

}

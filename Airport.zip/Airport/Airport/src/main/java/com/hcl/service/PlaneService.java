package com.hcl.service;

import java.util.List;
import java.util.Optional;

import com.hcl.model.Plane;

public interface PlaneService {

    List<Plane> getAllPlanes();

    Optional<Plane> findPlaneById(String planeID);

}

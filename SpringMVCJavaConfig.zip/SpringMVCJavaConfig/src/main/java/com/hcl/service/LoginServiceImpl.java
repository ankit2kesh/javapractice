package com.hcl.service;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.LoginDaoInterface;
import com.hcl.model.Login;
@Service
public class LoginServiceImpl implements LoginServiceInterface {
	@Autowired
	LoginDaoInterface dao;

	public void saveData(Login login) throws UnsupportedEncodingException {
		System.out.println("hello1");
		String base64encodedString = Base64.getEncoder().encodeToString(login.getPassword().getBytes("utf-8"));
		System.out.println("base64encodedString : " + base64encodedString);
		login.setPassword(base64encodedString);
		dao.saveData(login);

	}

	public void fetchAll() {
		System.out.println("ser fetch all");
		dao.fetchAll();
	}

	public void fetchById(int id) {
		System.out.println("serv fetch by ");
	}
}

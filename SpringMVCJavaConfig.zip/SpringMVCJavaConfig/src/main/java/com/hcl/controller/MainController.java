package com.hcl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	@RequestMapping("/")
	public String home() {
		System.out.println("index");
		return "index";
	}

	@RequestMapping("success")
	public String success() {
		System.out.println("success");
		return "redirect:/success_page";
	}

	@RequestMapping("success_page")
	public String successPage() {
		System.out.println("success_page");
		return "success_page";
	}
}

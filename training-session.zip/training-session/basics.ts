function add(num1: number, num2: number, result: string, showResult = false) {
    if (showResult === true)
        return num1 + num2
    return result;
}

let result = add(20, 34, "Please Wait.... ");
console.log(result);

result = add(6, 8, "Please Wait....", true);

console.log("This is the second Result " + result);

function combination(param1: number | string, param2: number | string) {
    if (typeof param1 === "number" && typeof param2 === "number")
        return param1 + param2;
    if (typeof param1 === "string" && typeof param2 === "string")
        return param1.toString() + param2.toString();

    return param1.toString() + param2.toString();
}

let combineResult = combination(20, 30);
console.log(combineResult);

let strCombineResult = combination("HTML", "Typescript ");
console.log("This time with a string ", strCombineResult)

//Arrow Function: Javascript

const combinationArrow = (num1: number, num2: number) => { return num1 + num2 }

console.log(combinationArrow(29, 32));

// combinationArrow = (input1: number, input2: number) => { return input1 }

console.log(combinationArrow(23, 123));

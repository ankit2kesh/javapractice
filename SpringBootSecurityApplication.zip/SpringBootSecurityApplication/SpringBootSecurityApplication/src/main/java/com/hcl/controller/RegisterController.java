
package com.hcl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.RegisterUser;
import com.hcl.service.RegisterService;

@Controller
public class RegisterController {

	@Autowired
	private RegisterService registerService;

	@RequestMapping("RegisterAdmin")
	public ModelAndView showAdminRegPage(@ModelAttribute("regAdmin") RegisterUser regUser) {
		return new ModelAndView("RegisterAdmin");
	}

	@RequestMapping("SaveAdmin")
	public ModelAndView registeAdmin(@ModelAttribute("regAdmin") RegisterUser regAdmin, BindingResult result) {
		if (result.hasErrors()) {
			return new ModelAndView("RegisterAdmin");
		}
		registerService.saveUser(regAdmin);
		return new ModelAndView("SuccessAdmin");
	}

	@RequestMapping("RegisterMan")
	public ModelAndView showManagerRegPage(@ModelAttribute("regManager") RegisterUser regManager)

	{
		return new ModelAndView("RegisterMan");
	}

	@RequestMapping("SaveManager")
	public ModelAndView registeManager(@ModelAttribute("regManager") RegisterUser regManager, BindingResult result) {
		if (result.hasErrors()) {
			return new ModelAndView("RegisterMan");
		}
		registerService.saveUser(regManager);
		return new ModelAndView("SuccessManager");
	}

}

import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute, Params } from '@angular/router';
@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {
fullname:String="ankit";
id;
  constructor(private activatedRoute: ActivatedRoute) {
    
   }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id')
    console.log(this.id);
    // const user:{first:'Ram',lastName:'seeta'};
    // user.sapid=1000;
    // console.log(user);
    var a=new Array(4).toString();
    console.log("kkk"+a);
    var myArr=['HTML','CSS','js'];
    myArr[2];
    console.log('2' in myArr);
    // console.log(false > 20 + true);
    console.log(typeof this.aaa());
  }
aaa(){
  return{
    test :1
  };
}
}

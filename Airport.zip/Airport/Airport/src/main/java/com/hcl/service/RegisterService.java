
package com.hcl.service;

import com.hcl.model.User;

public interface RegisterService {

	public User saveUser(User regAdmin);

}


package com.hcl.service;

import com.hcl.model.Login;

public interface LoginService {

	public Login saveData(Login login);
}

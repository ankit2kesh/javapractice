package com.hcl.carinventory;

import java.text.NumberFormat;
import java.util.List;
import java.util.Scanner;
import lombok.Setter;

@Setter
public class CarService {
	Car c;
	CarDao cdao;

	public void operations() {
		System.out.println("Enter Command : ");
		Scanner sc = new Scanner(System.in);
		String command = sc.next();
		if (command.equalsIgnoreCase("quit")) {
			System.out.println("Good bye!");
		} else {
			if (command.equalsIgnoreCase("add")) {
				System.out.println("Enter Car Id : ");
				c.setCar_id(sc.nextInt());
				System.out.println("Enter Maker :");
				c.setMake(sc.next());
				System.out.println("Enter Model :");
				c.setModel(sc.next());
				System.out.println("Enter Year :");
				c.setYear(sc.nextInt());
				System.out.println("Enter Sale Price in ($)");
				c.setSalePrice(sc.nextDouble());
				int i = cdao.addCar(c);
				System.out.println(i + " record inserted into the database successfully.");
			} else if (command.equalsIgnoreCase("update")) {
				System.out.println("Enter car Id to update car details");
				int carId = sc.nextInt();
				System.out.println("Enter which details you want to update");
				System.out.println("Make :");
				System.out.println("Model :");
				System.out.println("Year :");
				System.out.println("Sale Price ");
				System.out.println("--------------------------------------------");
				String detailToUpdate = sc.next();
				System.out.println("Enter new " + detailToUpdate);
				if (detailToUpdate.equalsIgnoreCase("make") || detailToUpdate.equalsIgnoreCase("model")
						|| detailToUpdate.equalsIgnoreCase("year")
						|| detailToUpdate.trim().equalsIgnoreCase("saleprice")) {
					String newDetails = sc.next();
					int i = cdao.updateCar(detailToUpdate, newDetails, carId);
					System.out.println(i + " record updated into the database successfully.");
				} else {
					System.out.println("Sorry, but " + detailToUpdate + " is not a valid command. Please try again");
				}

			} else if (command.equalsIgnoreCase("delete")) {
				System.out.println("Enter car id to delete : ");
				int carId = sc.nextInt();
				int i = cdao.deleteCar(carId);
				System.out.println(i + " record deleted from the database successfully.");
			} else if (command.equalsIgnoreCase("list")) {
				List<Car> list = cdao.showCar();
				if (list.size() == 0) {
					System.out.println("There are currently no cars in the catalog.");
				} else {
					NumberFormat formatter = NumberFormat.getCurrencyInstance();
					list.forEach(l -> System.out.println(l));
					Double totalInventory = list.stream().mapToDouble(j -> j.getSalePrice()).sum();
					System.out.println("");
					System.out.println("Numbers of Cars : " + list.size());
					System.out.println("Total inventory : " + formatter.format(totalInventory));
					System.out.println("");
				}
			} else {
				System.out.println("Sorry, but " + command + " is not a valid command. Please try again");
			}
			operations();
		}
	}

}

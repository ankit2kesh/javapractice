package com.hcl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.model.Plane;
import com.hcl.service.PlaneService;

@RestController
public class PlaneController {
    
    @Autowired
    private PlaneService planeService;
    
    @GetMapping(value = "/getAllPlanes" ,produces =MediaType.APPLICATION_JSON_VALUE)
    public List<Plane> getAllPlanes(){
        return planeService.getAllPlanes();
    }
    
    @GetMapping(value = "/getPlaneById/{planeID}" ,produces =MediaType.APPLICATION_JSON_VALUE)
    public Optional<Plane> getPlaneById(@PathVariable(name ="planeID") String planeID ){
        return planeService.findPlaneById(planeID);
    }
    
    @PostMapping(value = "/updatePlane/{planeID}/{planeName}")
    public Plane updatePlaneDetails(@PathVariable(name ="planeID" ,required = false)String planeID
            ,@PathVariable(name ="planeName",required = false)String planeName){
        return null;
        
    }

}

package com.hcl.mapping;

import java.util.LinkedList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ManyMain {
	public static void main(String[] args) {
		try {
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");// cfg.xml,hbm.xml
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
//			Answer answer=new Answer();
//			answer.setAnswername("Java is PL");
//			answer.setPostedBy("Revathi");
//			Answer answer1=new Answer();
//			answer1.setAnswername("Java is Platfoem");
//			answer1.setPostedBy("Drishna");
//			List list=new LinkedList();
//			list.add(answer1);
//			list.add(answer);
//			Question question=new Question();
//			question.setQname("What is Java");
//			question.setAnswers(list);
//			session.save(question);
//			tx.commit();
			
			Question q=session.get(Question.class, 1);
			List<Answer> ls=q.getAnswers();
			for(Answer a:ls)
				System.out.println(a.getAnswername());
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}

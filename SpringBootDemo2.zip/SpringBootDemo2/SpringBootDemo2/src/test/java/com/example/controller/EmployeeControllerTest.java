package com.example.controller;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeControllerTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

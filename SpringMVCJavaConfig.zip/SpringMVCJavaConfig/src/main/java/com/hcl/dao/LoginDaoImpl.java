package com.hcl.dao;

import org.springframework.stereotype.Repository;

import com.hcl.model.Login;

@Repository
public class LoginDaoImpl implements LoginDaoInterface {

	
	public void saveData(Login login) {
		System.out.println("hello2");
		

	}

	public void fetchAll() {
		System.out.println("fetch all");
	}

	public void fetchById(int id) {
		System.out.println("fetchby id");
	}
}

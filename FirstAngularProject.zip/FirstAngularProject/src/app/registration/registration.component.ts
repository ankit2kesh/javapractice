import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Logger } from '../service/logger.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  formdata;
  name;
  emailid;
  passwd;
  passwd_repeat;
  user = [];
  flag: boolean = false;
  isPageLoaded: boolean = false;
  constructor(private logger:Logger) { }

  ngOnInit(): void {
    setTimeout(() => {
      this.isPageLoaded = true;
    }, 5000)
    // this.CalculateAge();
    this.formdata = new FormGroup({
      name: new FormControl("", Validators.required),
      dob: new FormControl("", Validators.required),
      emailid: new FormControl("", Validators.compose([
        Validators.required,
        Validators.pattern("[^ @]*@[^ @]*")
      ])),
      passwd: new FormControl("", Validators.required),
      passwd_repeat: new FormControl("", Validators.required)
    });
  }
  // passwordvalidation(formcontrol) {
  //   if (formcontrol.value.length < 5) {
  //     alert("password should be greater than 5");
  //     return { "passwd": true };
  //   }
  // }

  public dob: string;
  public age: number;

  public CalculateAge(): number {
    // this.dob = "10/15/1992";
    if (this.dob) {
      var timeDiff = Math.abs(Date.now() - new Date(this.dob).getTime());
      this.age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
      console.log(this.age)
      return this.age;
    }
  }

  onClickSubmit(data) {
    this.name = data.name;
    this.emailid = data.emailid;
    this.passwd = data.passwd;
    this.passwd_repeat = data.passwd_repeat;
    this.dob = data.dob;

    let totalAge = this.CalculateAge();
    console.log("totalAge : " + totalAge);

    data.dob = totalAge;

    this.user.push(data);
    console.log(this.user);

    console.log("dob : " + this.dob);

    console.log("this.emailid : " + this.emailid);

    console.log("this.passwd : " + this.passwd);

    console.log("this.passwd_repeat : " + this.passwd_repeat);

    this.logger.consoleLogger(this.name);
    this.logger.consoleLogger(this.emailid);
    this.logger.consoleLogger(this.passwd);
    this.logger.consoleLogger(this.passwd_repeat);
    this.logger.consoleLogger(this.dob);

    this.flag = true;
  }
  reset() {

    this.formdata.reset();
  }

}

package main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import main.dao.EmployeeDaoIntf;
import main.model.Employee;

@Component
@Transactional
public class EmployeeServiceImpl implements EmployeeServiceIntf {

	@Autowired
	EmployeeDaoIntf edi;

	public void saveData(Employee employee) {
		edi.saveData(employee);

	}

	@Override
	public Employee fetchById(int id) {

		return edi.fetchById(id);
	}

	@Override
	public List<Employee> readAll() {

		return edi.fetchAll();
	}

	@Override
	public void deleteById(int id) {

		edi.deleteById(id);
	}

}

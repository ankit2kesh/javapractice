
package com.hcl.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.User;
import com.hcl.service.RegisterService;

@Controller
public class RegisterController {

	@Autowired
	private RegisterService registerService;

	@RequestMapping("RegisterAdmin")
	public ModelAndView showAdminRegPage(@ModelAttribute("regAdmin") User regAdmin) {
		return new ModelAndView("RegisterAdmin");
	}

	// @RequestMapping(value = "/SaveUser", consumes =
	// MediaType.APPLICATION_JSON_VALUE)
	// public Register showAdminRegPage(@RequestBody @Valid Register register) {
	// return registerService.saveUser(register);
	// }

	@RequestMapping("SaveAdmin")
	public ModelAndView registeAdmin(@ModelAttribute("regAdmin") @Valid User regAdmin, BindingResult result) {
		if (result.hasErrors()) {
			return new ModelAndView("RegisterAdmin");
		}
		registerService.saveUser(regAdmin);
		return new ModelAndView("SuccessAdmin");
	}

	@RequestMapping("RegisterMan")
	public ModelAndView showManagerRegPage(@ModelAttribute("regManager") User regManager)

	{
		return new ModelAndView("RegisterMan");
	}

	@RequestMapping("SaveManager")
	public ModelAndView registeManager(@ModelAttribute("regManager") @Valid User regManager, BindingResult result) {
		if (result.hasErrors()) {
			return new ModelAndView("RegisterMan");
		}
		registerService.saveUser(regManager);
		return new ModelAndView("SuccessManager");
	}

}

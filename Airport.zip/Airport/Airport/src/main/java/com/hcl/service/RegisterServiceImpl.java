
package com.hcl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.RegisterDao;
import com.hcl.model.User;

@Service
public class RegisterServiceImpl implements RegisterService {
	@Autowired
	private RegisterDao registerDao;

	public User saveUser(User regAdmin) {
		return registerDao.saveUser(regAdmin);

	}
}

package com.hcl.dao;

import com.hcl.model.Hangar;
import com.hcl.model.Pilot;
import com.hcl.model.Plane;

public interface AdminDao {

    Plane addPlane(Plane plane);

    Pilot addPilot(Pilot pilot);

    Hangar addHanager(Hangar hangar);

}

package com.hcl.service;

import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.EmployeeDaoInterface;
import com.hcl.model.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeServiceInterface {
	@Autowired
	EmployeeDaoInterface edi;

	public void saveData(Employee employee) {
		edi.saveData(employee);
	}

	public void saveOrData(Employee employee) {
		edi.saveOrData(employee);
	}

	public void delete(int id) {
		edi.delete(id);
	}

	public List<Employee> readAll() {

		List<Employee> listAll = (List<Employee>) edi.readAll();
		return listAll;
	}

}


package com.hcl.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class LoginController {

    @RequestMapping("/home")
    public ModelAndView showIndexPage() {
        return new ModelAndView("index");
    }

    @RequestMapping("/LoginAdmin")
    public ModelAndView showLoginPageAdmin(@RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout) {
        if (error != null) {
            return new ModelAndView("LoginAdmin", "error", "Invalid login Credentials");
        } else if (logout != null) {
            return new ModelAndView("LoginAdmin", "message", "Logged Out Successfully");
        }
        return new ModelAndView("LoginAdmin");
    }

    //    @RequestMapping( value = "/LoginAdmin",consumes =MediaType.APPLICATION_JSON_VALUE)
    //    public Login showLoginPageAdmin(@RequestBody @Valid Login login) {
    //        return loginService.saveData(login);
    //    }

    @RequestMapping("/adminHome")
    public ModelAndView showAdminWorkPage() {
        //loginService.saveData(login);
        return new ModelAndView("AdminHome");
    }

    @RequestMapping("/403")
    public ModelAndView showAccesssDeniedPage() {
        return new ModelAndView("access_denied", "msg", "You dont have permission to access this page!");
    }
    //    
    //    @PostMapping(value = "/LoginManager" , consumes =MediaType.APPLICATION_JSON_VALUE )
    //    public Login showLoginPageManager(@RequestBody @Valid Login login) {
    //        return loginService.saveData(login);
    //    }

    @RequestMapping("/LoginManager")
    public ModelAndView showLoginPageManager(@RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout) {
        if (error != null) {
            return new ModelAndView("LoginManager", "error", "Invalid login Credentials");
        } else if (logout != null) {
            return new ModelAndView("LoginManager", "message", "Logged Out Successfully");
        }
        return new ModelAndView("LoginManager");
    }

    @RequestMapping("/managerHome")
    public ModelAndView showManagerWorkPage() {
        return new ModelAndView("ManagerHome");
    }

}

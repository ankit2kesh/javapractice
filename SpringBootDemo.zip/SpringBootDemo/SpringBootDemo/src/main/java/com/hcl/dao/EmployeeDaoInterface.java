package com.hcl.dao;

import java.util.List;

import com.hcl.model.Employee;

public interface EmployeeDaoInterface {
	void saveData(Employee employee);

	void saveOrData(Employee employee);

	void delete(int id);

	List<Employee> readAll();
}


package com.hcl.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@NotEmpty(message = "Please update the highlighted mandatory field")
	private String firstname;
	@NotEmpty(message = "Please update the highlighted mandatory field")
	private String lastname;
	@NotEmpty(message = "Please update the highlighted mandatory field")
	private String age;
	@NotEmpty(message = "Please update the highlighted mandatory field")
	private String gender;
	@NotEmpty(message = "Please update the highlighted mandatory field")
	private String contactNo;
	@NotEmpty(message = "Please update the highlighted mandatory field")
	private String username;
	@NotEmpty(message = "Please update the highlighted mandatory field")
	private String password;
	@Column(name = "user_role", updatable = false, columnDefinition = "VARCHAR(1) NOT NULL COMMENT 'A = Admin , M = Manager'")
	private String userRole;

	public User(String username, String password, String userRole) {
		super();
		this.username = username;
		this.password = password;
		this.userRole = userRole;
	}

}

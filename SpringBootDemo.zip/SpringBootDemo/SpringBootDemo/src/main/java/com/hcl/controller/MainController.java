package com.hcl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.model.Employee;
import com.hcl.service.EmployeeServiceInterface;

@RestController
public class MainController {
	@Autowired
	EmployeeServiceInterface esi;

//	@RequestMapping("/")
//	public String home() {
//		return "home";
//	}
//
//	@PostMapping("addEmployee")
//	public String addEmployee() {
//		System.out.println("addEmployee");
//
//		return "addEmployee";
//	}

	@PostMapping("saveEmployee")
	public String saveEmployee(@RequestBody Employee employee) {
		System.out.println("saveEmployee");
		esi.saveData(employee);
		return "success";
	}

	@PutMapping("updateEmployee")
	public String updateEmployee(@RequestBody Employee employee) {
		System.out.println("saveEmployee");
		esi.saveOrData(employee);
		return "success";
	}

	@DeleteMapping("deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable("id") int id) {
		System.out.println("saveEmployee");
		esi.delete(id);
		return "success";
	}

	@GetMapping("getEmployee")
	public List<Employee> getEmployee() {
		System.out.println("saveEmployee");
		return esi.readAll();
	}
}

interface Employee {
    FirstName: string,
    LastName: string
}

// let emp: Employee;
// let empName: string;
// emp.FirstName = "Angular";
// emp.LastName = "TypeScript";

let emp1: any;

emp1 = "asdasd";
emp1 = { age: 12, gender: "Female" };


// const Emp: {
//     FirstName: string,
//     LastName: string,
//     age: number
// } = {
//     FirstName: "Angular",
//     LastName: "Typescript",
//     age: 23
// }

// const Emp: {
//     FirstName: string,
//     LastName: string,
//     CityOfTravel: string[],
//     FavTravelMonth: [number, string]
// } = {
const Emp = {
    FirstName: "Angel",
    LastName: "Heaven",
    CityOfTravel: ['India', 'Australia', 'canada'],
    FavTravelMonth: [1, 'March']
}

enum Role { HR = 101, ITI = 102, Admin = 103, Infra = 104 }
// const HR = 102;
// const IT = 103;

console.log(Role);

console.log(Emp.FavTravelMonth);

Emp.FavTravelMonth = ['June', 'July', "August"];
console.log(Emp.FavTravelMonth);

Emp.CityOfTravel.push('USA');
Emp.CityOfTravel.map((item) => { console.log(item) })

Emp.CityOfTravel.pop();


console.log(Emp.CityOfTravel);

let favourites: string[];
favourites = ['Rome', 'Finland'];
console.log(favourites);

for (const fav of favourites) {
    console.log(fav);
}
// console.log(Employee.FirstName + Employee.LastName);

// const emp = {};
let alpha = ["a", "b", "c"]; 
let numeric = ["1", "2", "3"];

let alphaNumeric = alpha.concat(numeric); 
console.log("alphaNumeric : " + alphaNumeric );

let num = [7, 8, 9];
num.forEach(function (value) {
  console.log(value);
}); 
let index = [12, 5, 8, 130, 44].indexOf(8); 
console.log("index is : " + index );

let arr = new Array("First","Second","Third"); 
          
let str1 = arr.join(); 
console.log("str1 : " + str1 );  
          
let str2 = arr.join(", "); 
console.log("str2 : " + str2 );  
          
let str3 = arr.join(" + "); 
console.log("str3 : " + str3 );

let index1 = [12, 5, 8, 130, 44].lastIndexOf(8); 
console.log("index is : " + index );

let numbers = [1, 4, 9]; 
let roots = numbers.map(Math.sqrt); 
console.log("roots is : " + roots );

let arr1 = ["orange", "mango", "banana", "sugar", "tea"]; 
console.log("arr.slice( 1, 2) : " + arr1.slice( 1, 2) );  
console.log("arr.slice( 1, 3) : " + arr1.slice( 1, 3) );

let arr2 = new Array("orange", "mango", "banana", "sugar"); 
let sorted = arr2.sort(); 
console.log("Returned string is : " + sorted );

let arr3 = new Array("orange", "mango", "banana", "sugar"); 
let length1 = arr3.unshift("water"); 
console.log("Returned array is : " + arr3 );
console.log("Length of the array is : " + length1 );

let total = [0, 1, 2, 3].reduce(function(a, b){ return a + b; }); 
console.log("total is : " + total );

var numbers1 = new Array(1, 4, 9); 
var length = numbers1.push(10); 
console.log("new numbers is : " + numbers1 );  
length = numbers1.push(20); 
console.log("new numbers is : " + numbers1 );

var numbers2 = [1, 4, 9]; 
          
var element = numbers2.pop(); 
console.log("element is : " + element );  
          
var element = numbers2.pop(); 
console.log("element is : " + element );



let obj={
    Name:"Angular",
    Duration:"2hr",
    Week:"4 weeks"
}
// const{Name, Duration}=obj
let[a,b,...rest]=[10,20,30,40,44,37];
console.log(a);
console.log(b);
console.log(rest);
package com.hcl.carinventory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarMain {

	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		CarService cs = ac.getBean("carService", CarService.class);
		System.out.println("WelCome to Car Catalog ");
		System.out.println("Enter add -> To add a car to the catalog ");
		System.out.println("Enter list -> To list all cars in the catalog ");
		System.out.println("Enter Delete -> To delete car ");
		System.out.println("Enter Update -> To update car Details");
		System.out.println("Enter Quit -> To quit car catalog");
		System.out.println("--------------------------------------------");
		cs.operations();
	}

}

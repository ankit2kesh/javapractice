package com.hcl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	@GetMapping("/")
	public String home() {
		System.out.println("home");
		return "index";
	}

	@RequestMapping("/login")
	public String loginPage() {
		System.out.println("login");
		return "login";
	}

	@GetMapping("/user")
	public String user() {
		System.out.println("user");
		return "user";
	}

	@GetMapping("/admin")
	public String admin() {
		System.out.println("admin");
		return "admin";
	}

	@RequestMapping("/logout-success")
	public String logoutPage() {
		System.out.println("logout");
		return "logout";
	}
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public ModelAndView accesssDenied() {
		ModelAndView model = new ModelAndView();
		model.addObject("msg", "You do not have permission to access this page!");

		model.setViewName("Access_Denied");
		return model;

	}
}

package com.hcl.carinventory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Car {
	private int car_id;
	private String make, model;
	private int year;
	private double salePrice;
	@Override
	public String toString() {
		return "Car [car_id=" + car_id + ", make=" + make + ", model=" + model + ", year=" + year + ", salePrice="
				+ salePrice + "]";
	}
	

}
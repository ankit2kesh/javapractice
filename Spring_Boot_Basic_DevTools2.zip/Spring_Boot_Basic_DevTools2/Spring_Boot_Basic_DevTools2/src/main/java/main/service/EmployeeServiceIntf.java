package main.service;

import java.util.List;

import main.model.Employee;

public interface EmployeeServiceIntf {

    void saveData(Employee employee);

    Employee fetchById(int id);

    List<Employee> readAll();
    
    void deleteById(int id);
}

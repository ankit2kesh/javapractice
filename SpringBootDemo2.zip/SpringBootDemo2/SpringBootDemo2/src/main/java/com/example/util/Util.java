package com.example.util;

import org.springframework.stereotype.Component;

@Component
public class Util {
	public void util() {
		System.out.println("this is util classs");
	}
}

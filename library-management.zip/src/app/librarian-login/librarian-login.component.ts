import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Book } from '../../model/book';
import { BookService } from '../../service/bookService/book.service';

@Component({
  selector: 'app-librarian-login',
  templateUrl: './librarian-login.component.html',
  styleUrls: ['./librarian-login.component.css']
})
export class LibrarianLoginComponent implements OnInit {

  title = "Librarian Login Successfull";
  books: Book[] = [];
  bookName = "";

  constructor(private bookService: BookService, private router: Router) { }
  getBooks(): void {
    this.bookService.getBooks().subscribe((data: any) => {
      this.books = data;
    })
  }
  ngOnInit(): void {
    this.getBooks();
  }

  viewDetails(bookId: number){
    this.router.navigate(['/view-detail', bookId]);
  }
}

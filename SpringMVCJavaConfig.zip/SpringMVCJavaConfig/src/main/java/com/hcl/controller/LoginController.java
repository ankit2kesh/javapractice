package com.hcl.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.Login;
import com.hcl.service.LoginServiceInterface;
import com.hcl.service.LoginServiceInterface;

@Controller
public class LoginController {
	@Value("${username}")
	String username;
	@Autowired
	LoginServiceInterface lsi;

	@RequestMapping("Login")
	public ModelAndView showLoginPage(@ModelAttribute("login") Login login)

	{
		System.out.println("hello -- "+username);
		return new ModelAndView("Login");
	}

//	@RequestMapping("Save")
	@RequestMapping(value = "/Save", method = RequestMethod.POST)
	public ModelAndView showSuccess(@ModelAttribute("login") @Valid Login login, BindingResult result)

	{
		if (result.hasErrors()) {
			return new ModelAndView("Login");
		}
		try {
			lsi.saveData(login);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("success1");// search requestMapping listData
	}

//	@RequestMapping("ListData")
//	public ModelAndView listData(@ModelAttribute("login") @Valid Login login, BindingResult result)
//
//	{
//
//		List<Login> list = lsi.fetchAll();
//		return new ModelAndView("Success", "listOfDetails", list);
//	}

//	@RequestMapping("ListData")
//	@RequestMapping(value = "/ListData", method = RequestMethod.GET)
//	@ResponseBody
//	public List<Login> listData()
//
//	{
//		List<Login> list = lsi.fetchAll();
//		return list;
//	}

//	@RequestMapping("listDataById")
//	@ResponseBody
//	public Login listDataById(@PathVariable("id") int id)
//
//	{
//		System.out.println("listDataById::");
//		Login l = lsi.fetchById(id);
//		return l;
//	}
}

package com.hcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.model.Login;

public interface LoginRepository extends JpaRepository<Login, Integer>{

}

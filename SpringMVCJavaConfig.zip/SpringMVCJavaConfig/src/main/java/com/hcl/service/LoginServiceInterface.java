package com.hcl.service;

import java.io.UnsupportedEncodingException;

import com.hcl.model.Login;

public interface LoginServiceInterface {
	void saveData(Login login) throws UnsupportedEncodingException;

	void fetchAll();

	void fetchById(int id);
}

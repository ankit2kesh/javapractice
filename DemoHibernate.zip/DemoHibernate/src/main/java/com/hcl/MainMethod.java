package com.hcl;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

public class MainMethod {

	public static void main(String[] args) {
//		Configuration conf=new Configuration().configure("hibernate.cfg.xml");
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		// transient state

//		Employee e = new Employee();
//		e.setId(2);
//		e.setName("abhijikkkkk");

//		Employee e = session.get(Employee.class, 2);
//		e.setName("abhijeekkkkkk");
//		Employee e = new Employee();
//		e.setId(2);
//		session.delete(e);

//		Query<Employee> q=session.createSQLQuery("select * from employee").addEntity(Employee.class);
//		Query<Employee> q=session.createNamedQuery("findEmployees");

//		Criteria c=session.createCriteria(Employee.class);  
//		c.setFirstResult(10);  
//		c.setMaxResults(15);  
//		c.add(Restrictions.lt("id",10));
//		c.addOrder(Order.desc("id"));  
//		c.setProjection(Projections.property("name")); 
//		List list=c.list();
//		List<Employee> ls=c.list();
//		System.out.println(ls);

//		ls.forEach(name->System.out.println(name.getName()+""+name.getId()));
//		
//		session.save(e);
		// persistent state
//		e.setName("abcd");
		
// Declare your store procedure inside the @NamedNativeQueries annotation.
//		Query query = session.getNamedQuery("getEmpDeatils");
//		List result = query.list();
//		for (int i = 0; i < result.size(); i++) {
//			Employee stock = (Employee) result.get(i);
//			System.out.println(stock.getName());
//		}
		
		Employee e=new Employee();
		e.setName("rohan");
		e.setCreateDate(Calendar.getInstance());

		
		session.save(e);
		t.commit();// permanent state
		session.close();// detached state
		System.out.println("saved data successfully.");

	}

}

package hackerrank_test6;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class EvenOddOperations {
	public static long getMaximumScore(List<Integer> integerArray) {
		// Write your code here
		CopyOnWriteArrayList<Integer> l = new CopyOnWriteArrayList(integerArray);
		int score = 0;
		int sum = 0;
		Iterator<Integer> it = l.listIterator();
		while (it.hasNext()) {
			Integer integer = (Integer) it.next();

			if (integer % 2 != 0) {
				score += sum(l);
				if (score<sum || l.size()<=3) {
					l.remove(0);
				}else {
					l.remove(l.size() - 1);
				}
//				l.remove(l.size() - 1);
				sum = sum(l);
			} else {
				score -= sum(l);
				if (score<sum) {
					l.remove(0);
				}else {
					l.remove(l.size() - 1);
				}
				
				sum = sum(l);
			}
		}
		System.out.println("score : " + Math.abs(score));
		return Math.abs(score);

	}

	static int sum(List<Integer> l) {
		int sum = 0;
		System.out.println(l);
		for (int i = 0; i < l.size(); i++) {
			sum += l.get(i);
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] a = { 1, 2, 3 };
		System.out.println(getMaximumScore(Arrays.asList(a)));
	}

}

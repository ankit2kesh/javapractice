package com.hcl.service;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.LoginDaoInterface;
import com.hcl.model.Login;

@Service
@org.springframework.transaction.annotation.Transactional
public class LoginServiceImpl implements LoginDaoInterface {

	@Autowired
	LoginDaoInterface dao;

	public void saveData(Login login) {
		System.out.println("hello1");
		String base64encodedString;
		try {
			base64encodedString = Base64.getEncoder().encodeToString(login.getPassword().getBytes("utf-8"));
			System.out.println("base64encodedString : " + base64encodedString);
			login.setPassword(base64encodedString);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		dao.saveData(login);

	}

	public List<Login> fetchAll() {
		List<Login> ls = dao.fetchAll();
		return ls;
	}

	public Login fetchById(int id) {
		return dao.fetchById(id);
	}

}

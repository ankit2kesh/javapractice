package main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class,HibernateJpaAutoConfiguration.class })
public class SpringBootApp2 implements CommandLineRunner{
	@Autowired
	private YAMLConfig myConfig;

	public static void main(String[] args) {
		//SpringApplication.run(SpringBootApp2.class, args);
		SpringApplication app = new SpringApplication(SpringBootApp2.class);
        app.run();
	}

	public void run(String... args) throws Exception {
		System.out.println("environment: " + myConfig.getEnvironment());
		System.out.println("name: " + myConfig.getName());
		System.out.println("servers: " + myConfig.getServers());
	}
}

/*
 * @Configuration
 * 
 * @EnableAutoConfiguration
 * 
 * @ComponentScan public class SpringBootApp1 { public static void main(String[]
 * args) { SpringApplication.run(SpringBootApp1.class, args); }
 * 
 * }
 */
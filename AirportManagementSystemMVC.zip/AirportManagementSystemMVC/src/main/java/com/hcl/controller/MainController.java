package com.hcl.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
//http://websystique.com/springmvc/spring-4-mvc-helloworld-tutorial-annotation-javaconfig-full-example/
//https://www.mkyong.com/spring-mvc/gradle-spring-4-mvc-hello-world-example-annotation/
//http://www.kubrynski.com/2014/01/understanding-spring-web-initialization.html
@RestController
public class MainController {

	
	@RequestMapping("/")
	public String welcomePage()
	{
		return "welcome";
	}
	@RequestMapping("/Success")
	public String successPage()
	{
		return "Success";
	}
	@RequestMapping("/403")
	public String accessdeniedPage()
	{
		return "Access_Denied";
	}
	@RequestMapping("/admin")
	public String adminPage()
	{
		return "Admin";
	}
	@RequestMapping("/loginPage")
	public ModelAndView loginPage(@RequestParam(value="error",required=false) String error,@RequestParam(value="logout",required=false) String logout)
	{
		if(error!=null)
		{

			return new ModelAndView("loginPage","error","Invalid Credentials provided.");
		}
		if(logout!=null)
		{
			return new ModelAndView("loginPage","logout","logout successfully");
		}
		return new ModelAndView("loginPage");
	}
}

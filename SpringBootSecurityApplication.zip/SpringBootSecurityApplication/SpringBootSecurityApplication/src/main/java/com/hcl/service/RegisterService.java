
package com.hcl.service;

import com.hcl.model.RegisterUser;

public interface RegisterService {

	public RegisterUser saveUser(RegisterUser regAdmin);

}

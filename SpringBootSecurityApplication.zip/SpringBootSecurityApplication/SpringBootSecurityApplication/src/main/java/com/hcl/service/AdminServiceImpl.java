package com.hcl.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.AdminDao;
import com.hcl.model.Hangar;
import com.hcl.model.Pilot;
import com.hcl.model.Plane;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {
    
    @Autowired
    private AdminDao adminDao;

    @Override
    public Plane addPlane(Plane plane) {
        return adminDao.addPlane(plane);
    }

    @Override
    public Pilot addPilot(Pilot pilot) {
        return adminDao.addPilot(pilot);
    }

    @Override
    public Hangar addHangar(Hangar hangar) {
        return adminDao.addHanager(hangar);
    }

}

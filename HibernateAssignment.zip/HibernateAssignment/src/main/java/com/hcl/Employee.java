package com.hcl;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "emp_info")
// for creating second table
@SecondaryTable(name = "emp_details", pkJoinColumns = @PrimaryKeyJoinColumn(name = "empid"))
// for calling named query with store procedure
@NamedNativeQueries({
		@NamedNativeQuery(name = "getEmpInfo", query = "CALL getEmpInfo()", resultClass = Employee.class) })
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	@Column(table = "emp_details")
	private String email;
	@Column(table = "emp_details")
	private double salary;
	// creating column in secondary table
	@Column(table = "emp_details")
	// for storing date object in database
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date joiningDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", salary=" + salary + ", joiningDate="
				+ joiningDate + "]";
	}

}

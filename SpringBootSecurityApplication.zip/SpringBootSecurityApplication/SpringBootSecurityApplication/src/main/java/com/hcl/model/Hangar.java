
package com.hcl.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Hangar {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@NotEmpty(message = "please enter hanagrId")
	private String hangarId;
	@NotEmpty(message = "please enter hangar status")
	private String hangarStatus;
	@OneToMany(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "hid")
	private List<Plane> planes;

}

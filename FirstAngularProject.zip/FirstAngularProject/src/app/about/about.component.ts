import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  value: number = 5;
  isPageLoaded: boolean = false;
  constructor() { }

  title = 'Angular 4 Project!';
  todaydate = new Date();
  jsonval = { name: 'Rox', age: '25', address: { a1: 'Mumbai', a2: 'Karnataka' } };
  months = ["Jan", "Feb", "Mar", "April", "May", "Jun",
    "July", "Aug", "Sept", "Oct", "Nov", "Dec"];

  ngOnChanges() {
    console.log("ngOnChanges : ");

  }
  ngOnInit(): void {
    setTimeout(() => {
      this.isPageLoaded = true;
    }, 5000)
  }
  ngDoCheck() {
    console.log("ngDoCheck : ");
  }
  ngAfterContentInit() {
    console.log("ngAfterContentInit : ");
  }
  ngAfterContentChecked() {
    console.log("ngAfterContentChecked : ");
  }
  ngAfterViewInit() {
    console.log("ngAfterViewInit : ");
  }
  ngAfterViewChecked() {
    console.log("ngAfterViewChecked : ");
  }
  ngOnDestroy() {
    console.log("ngOnDestroy : ");
  }
  getColor = () => {
    return this.isPageLoaded === true ? "crimson" : "blue";
  }

}

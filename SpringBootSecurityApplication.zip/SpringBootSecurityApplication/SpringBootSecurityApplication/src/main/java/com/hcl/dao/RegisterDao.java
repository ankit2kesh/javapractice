
package com.hcl.dao;

import com.hcl.model.RegisterUser;


public interface RegisterDao {

    public RegisterUser saveUser(RegisterUser regUser);


}

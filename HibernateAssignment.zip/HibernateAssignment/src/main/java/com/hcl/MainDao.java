package com.hcl;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class MainDao {

	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
//      saving object in database
		Employee e = new Employee();
		e.setName("aman");
		e.setEmail("aman@gmail.com");
		e.setSalary(25000);
		e.setJoiningDate(new Date());
		session.save(e);
		t.commit();
//		fetching data from the database using store procedure in native named query
//		Query query = session.getNamedQuery("getEmpInfo");
//		List<Employee> list = query.list();
//		list.forEach(System.out::println);

		session.close();

	}

}

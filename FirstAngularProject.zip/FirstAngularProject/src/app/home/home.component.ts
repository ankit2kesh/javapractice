import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  fullname: String = "Amit";
  constructor(private activatedRoute: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    console.log(this.activatedRoute.snapshot.queryParams.name);
    console.log(this.activatedRoute.snapshot.params['id']);
    console.log(this.activatedRoute.snapshot.queryParams);

    this.activatedRoute.params.subscribe(
      (params: Params) => {
        console.log(params.name);
        console.log(params.id);
      }
    )
    this.activatedRoute.queryParams.subscribe(
      (params: Params) => {
        console.log(params.session)
      }
    )
    this.activatedRoute.fragment.subscribe(
      (fragValue) => {
        console.log("fragvalue : "+fragValue)
      }
    )
  }
  onHomeClick() {
    this.router.navigate(['/home', 'ankit', 24], { queryParams: { session: 'react' }, fragment: 'Awake' });
    // this.router.navigate(['/login']);
  }
}

package com.hcl.carinventory;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class CarDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int addCar(Car c) {
		String query = "insert into car_inventory values('" + c.getCar_id() + "','" + c.getMake() + "','" + c.getModel()
				+ "','" + c.getYear() + "','" + c.getSalePrice() + "')";
		return jdbcTemplate.update(query);
	}

	public int updateCar(String detailToUpdate, String newDetails, int carId) {
		String query = "update car_inventory set " + detailToUpdate + "=" + "'" + newDetails + "' where car_id = "
				+ carId;
		System.out.println(query);
		return jdbcTemplate.update(query);
	}

	public int deleteCar(int carId) {
		String query = "delete from car_inventory where car_id=" + carId;
		return jdbcTemplate.update(query);
	}

	public List<Car> showCar() {
		String query = "select * from car_inventory";
		return jdbcTemplate.query(query, new BeanPropertyRowMapper(Car.class));
	}
}
